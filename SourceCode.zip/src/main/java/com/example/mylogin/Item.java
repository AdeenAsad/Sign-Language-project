package com.example.mylogin;
public class Item {
    String signName;
    int signImage;

    public Item(String signName,int signImage)
    {
        this.signImage=signImage;
        this.signName=signName;
    }
    public String getSignName()
    {
        return signName;
    }
    public int getSignImage()
    {
        return signImage;
    }
}
