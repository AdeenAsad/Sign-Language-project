package com.example.mylogin;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;
import java.util.ArrayList;



public class Dictionary extends AppCompatActivity {
    GridView simpleList;
    ArrayList<Item> signList=new ArrayList<>();
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dictionary);
        simpleList = (GridView) findViewById(R.id.simpleGridView);
        signList.add(new Item("A", R.drawable.a1));
        signList.add(new Item("B", R.drawable.b1));
        signList.add(new Item("C", R.drawable.c1));
        signList.add(new Item("D", R.drawable.d1));
        signList.add(new Item("E", R.drawable.e1));
        signList.add(new Item("F", R.drawable.f1));
        signList.add(new Item("G", R.drawable.g1));
        signList.add(new Item("H", R.drawable.h1));
        signList.add(new Item("I", R.drawable.i1));
        signList.add(new Item("J", R.drawable.j1));
        signList.add(new Item("K", R.drawable.k1));
        signList.add(new Item("L", R.drawable.l1));
        signList.add(new Item("M", R.drawable.m1));
        signList.add(new Item("N", R.drawable.n1));
        signList.add(new Item("O", R.drawable.o1));
        signList.add(new Item("P", R.drawable.p1));
        signList.add(new Item("Q", R.drawable.q1));
        signList.add(new Item("R", R.drawable.r1));
        signList.add(new Item("S", R.drawable.s2));
        signList.add(new Item("T", R.drawable.t1));
        signList.add(new Item("U", R.drawable.u1));
        signList.add(new Item("V", R.drawable.v1));
        signList.add(new Item("W", R.drawable.w1));
        signList.add(new Item("X", R.drawable.x1));
        signList.add(new Item("Y", R.drawable.y1));
        signList.add(new Item("Z", R.drawable.z1));

        MyAdapter myAdapter = new MyAdapter(this, R.layout.activity_grid_view_items, signList);
        simpleList.setAdapter(myAdapter);
    }
}