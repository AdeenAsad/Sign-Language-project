package com.example.mylogin;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import android.os.Bundle;

public class avatar extends AppCompatActivity {

    private EditText keywordEditText;
    private Button searchButton;
    private ImageView resultImageView;
    // Define the default drawable resource ID
    private int defaultDrawableId = R.drawable.s1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avatar);
        keywordEditText = findViewById(R.id.keywordEditText);
        searchButton = findViewById(R.id.searchButton);
        resultImageView = findViewById(R.id.resultImageView);

        // Set the default drawable
        resultImageView.setImageResource(defaultDrawableId);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String keyword = keywordEditText.getText().toString().trim().toLowerCase();

                int resourceId = getResources().getIdentifier(keyword, "drawable", getPackageName());
                if (resourceId != 0) {
                    resultImageView.setImageResource(resourceId);
                } else {
                    Toast.makeText(avatar.this, "Translation not found", Toast.LENGTH_SHORT).show();
                    // Set the default drawable if not found
                    resultImageView.setImageResource(defaultDrawableId);
                }
            }
        });
    }
}