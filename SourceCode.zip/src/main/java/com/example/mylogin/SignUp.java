package com.example.mylogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.vishnusivadas.advanced_httpurlconnection.PutData;

import java.util.Objects;
import java.util.regex.Pattern;

public class SignUp extends AppCompatActivity {
    TextInputEditText textInputEditTextFullname, textInputEditTextUsername, textInputEditTextPassword, textInputEditTextEmail;
    Button buttonSignUp;
    Button showHidebtn;
    TextView textViewLogin;
    //ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        textInputEditTextFullname =findViewById(R.id.fullname);
        textInputEditTextUsername =findViewById(R.id.username);
        textInputEditTextPassword =findViewById(R.id.password);
        textInputEditTextEmail =findViewById(R.id.email);
        buttonSignUp =findViewById(R.id.buttonSignUp);
        textViewLogin =findViewById(R.id.loginText);
        //progressBar =findViewById(R.id.progress);
        showHidebtn= findViewById(R.id.showHidebtn);
        showHidebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(textInputEditTextPassword.getText().toString().isEmpty()){
                    textInputEditTextPassword.setError("Please Enter Password");
                } else {
                    if(showHidebtn.getText().toString().equals("Show")){
                        showHidebtn.setText("Hide");
                        textInputEditTextPassword.setTransformationMethod(null);
                    } else {
                        showHidebtn.setText("Show");
                        textInputEditTextPassword.setTransformationMethod(new PasswordTransformationMethod());
                    }
                }
            }

        });
        textViewLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Login.class);
                startActivity(intent);
                finish();
            }
        });

        buttonSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fullname,username,password,email;
                //fullname = Objects.requireNonNull(textInputEditTextFullname.getText()).toString().trim();
                //username = Objects.requireNonNull(textInputEditTextUsername.getText()).toString().trim();
               //password = textInputEditTextname.getText().toString().trim();
                //email = textInputEditTextUsername.getText().toString().trim();
                fullname = String.valueOf(textInputEditTextFullname.getText());
               username = String.valueOf(textInputEditTextUsername.getText());
                password = String.valueOf(textInputEditTextPassword.getText());
                email = String.valueOf(textInputEditTextEmail.getText());
                if(!fullname.equals("") && !username.equals("") && !password.equals("") && !email.equals("")) {
                    //progressBar.setVisibility(View.VISIBLE);
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.post(new Runnable() {
                        @Override
                        public void run() {


                            String[] field = new String[4];
                            field[0] = "fullname";
                            field[1] = "username";
                            field[2] = "password";
                            field[3] = "email";

                            String[] data = new String[4];
                            data[0] = fullname;
                            data[1] = username;
                            data[2] = password;
                            data[3] = email;

                            Pattern pattern=Pattern.compile("^" +
                                    "(?=.*[0-9])" +         //at least 1 digit
                                    "(?=.*[a-z])" +         //at least 1 lower case letter
                                    "(?=.*[A-Z])" +         //at least 1 upper case letter
                                    "(?=.*[@#$%^&+=])" +    //at least 1 special character
                                    "(?=\\S+$)" +           //no white spaces
                                    ".{6,15}" +               //at least 8 characters
                                    "$");
//                            Pattern usernameValidator=Pattern.compile("^[A-Za-z]\\w{5,29}$");


                            if(fullname.isEmpty())
                            {
                                textInputEditTextFullname.setError("Enter Name");
                                textInputEditTextFullname.requestFocus();
                                return;
                            }
                            if(fullname.length() <= 3)
                            {
                                textInputEditTextFullname.setError("Name should be greater than 3 letter's");
                                textInputEditTextFullname.requestFocus();
                                return;
                            }
                            if(fullname.length() > 20)
                            {
                                textInputEditTextFullname.setError("Name should be less than 20 letter's");
                                textInputEditTextFullname.requestFocus();
                                return;
                            }
                            if(!fullname.matches("[a-z A-Z]+"))
                            {
                                textInputEditTextFullname.setError("Only Letters are allowed");
                                textInputEditTextFullname.requestFocus();
                                return;
                            }
                            if(email.isEmpty())
                            {
                                textInputEditTextEmail.setError("Enter Email");
                                textInputEditTextEmail.requestFocus();
                                return;
                            }
                            if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
                            {

                                textInputEditTextEmail.setError("Enter Valid Email");
                                textInputEditTextEmail.requestFocus();
                                return;
                            }
                            if(username.isEmpty())
                            {
                                textInputEditTextUsername.setError("Enter username");
                                textInputEditTextUsername.requestFocus();
                                return;
                            }

                            if(!username.matches("^[A-Za-z]\\w{5,29}$"))
                            {
                                textInputEditTextUsername.setError("Invalid username");
                                textInputEditTextUsername.requestFocus();
                                return;
                            }



                            if(password.isEmpty())
                            {
                                textInputEditTextPassword.setError("Enter password");
                                textInputEditTextPassword.requestFocus();
                                return;
                            }
                            if(!pattern.matcher(password).matches())
                            {
                                textInputEditTextPassword.setError("Password should consist at least one digit, one lower, one upper, one special, no whitespaces and must be at least 8 characters");
                                textInputEditTextPassword.requestFocus();
                                return;
                            }

                            else {
                                PutData putData = new PutData("http://192.168.197.95/LoginRegister/signup.php?_ijt=rpokefq5g2cn34ustkvn933r5e&_ij_reload=RELOAD_ON_SAVE", "POST", field, data);
                                if (putData.startPut()) {
                                    if (putData.onComplete()) {
                                       // progressBar.setVisibility(View.GONE);
                                        String result = putData.getResult();
                                        if (result.equals("Sign Up Success")) {
                                            Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                                            Intent intent = new Intent(getApplicationContext(), Login.class);
                                            startActivity(intent);
                                            finish();
                                        } else {

                                            Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();

                                        }

                                    }
                                }
                            }
                        }
                    });
                }else
                {
                    Toast.makeText(getApplicationContext(), "All fields required", Toast.LENGTH_SHORT).show();
                }

            }

        });




    }
}