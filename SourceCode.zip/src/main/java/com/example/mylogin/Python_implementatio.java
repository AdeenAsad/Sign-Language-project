package com.example.mylogin;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class Python_implementatio extends AppCompatActivity {

    View btn;
    View btn2;
    View btn3;
    TextView tv;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_python_implementatio);

        tv = findViewById(R.id.tv);
        btn = findViewById(R.id.button);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fun();
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new  Intent(getBaseContext(), Listview.class);
                startActivity(intent);

            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new  Intent(getBaseContext(), avatar.class);
                startActivity(intent);

            }
        });



    }
    private void fun() {

        if (! Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }
        Python py =Python.getInstance();
        PyObject pyobj =py.getModule("myscript");

        PyObject obj = pyobj.callAttr("main");

        tv.setText(obj.toString());

    }

}