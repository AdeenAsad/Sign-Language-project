package com.example.mylogin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.ListView;
import android.os.Bundle;
import android.widget.SearchView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Listview extends AppCompatActivity {
    ListView listview ;
    int images[] = {R.drawable.a1,R.drawable.b1,R.drawable.c1,R.drawable.d1,R.drawable.e1,R.drawable.f1,R.drawable.g1,R.drawable.h1,R.drawable.i1,R.drawable.j1,R.drawable.k1,R.drawable.l1,R.drawable.m1,R.drawable.n1,R.drawable.o1,R.drawable.p1,R.drawable.q1,R.drawable.r1,R.drawable.s2,R.drawable.t1,R.drawable.u1,R.drawable.v1,R.drawable.w1,R.drawable.x1,R.drawable.y1,R.drawable.z1};
    String names[] = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
    String desc[] = {"Sign for A","Sign for B","Sign for C","Sign for D","Sign for E","Sign for F","Sign for G","Sign for H","Sign for I","Sign for J","Sign for K","Sign for L","Sign for M","Sign for N","Sign for O","Sign for P","Sign for Q","Sign for R","Sign for S","Sign for T","Sign for U","Sign for V","Sign for W","Sign for X","Sign for Y","Sign for Z"};
    List<ItemsModel> listItems = new ArrayList<>();

    CustomAdapter customAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview);

        listview = findViewById(R.id.listview);
        for (int i = 0; i < names.length;i++){
            ItemsModel itemsModel = new ItemsModel(names[i],desc[i],images[i]);
            listItems.add(itemsModel);
        }
        customAdapter = new CustomAdapter(listItems,this);
        listview.setAdapter(customAdapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        MenuItem menuItem = menu.findItem(R.id.search_view);
        SearchView searchView = (SearchView) menuItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                customAdapter.getFilter().filter(newText);
                return true;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.search_view){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public class CustomAdapter extends BaseAdapter implements Filterable {
        private List<ItemsModel> itemsModelList;
        private List<ItemsModel> itemsModelListFiltered;
        private Context context;

        public CustomAdapter(List<ItemsModel> itemsModelList,Context context) {
            this.itemsModelList = itemsModelList;
            this.itemsModelListFiltered =itemsModelList;
            this.context = context;
        }


        @Override
        public int getCount() {
            return itemsModelListFiltered.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = getLayoutInflater().inflate(R.layout.rows_items,null);
            ImageView imageView = view.findViewById(R.id.imageView);
            TextView itemName = view.findViewById(R.id.itemName);
            TextView itemDesc = view.findViewById(R.id.itemDesc);

            imageView.setImageResource(itemsModelListFiltered.get(position).getImage());
            itemName.setText(itemsModelListFiltered.get(position).getName());
            itemDesc.setText(itemsModelListFiltered.get(position).getDesc());
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(Listview.this,ItemViewActivity.class).putExtra("item",itemsModelListFiltered.get(position)));
                }
            });
            return view;
        }

        @Override
        public Filter getFilter() {
            Filter filter = new Filter() {
                @Override
                protected FilterResults performFiltering(CharSequence constraint) {
                    FilterResults filterResults =new FilterResults();
                    if(constraint == null || constraint.length() == 0) {
                        filterResults.count = itemsModelList.size();
                        filterResults.values = itemsModelList;
                    }else{
                        String searchStr = constraint.toString().toLowerCase();
                        List<ItemsModel> resultsData = new ArrayList<>();
                        for(ItemsModel itemsModel:itemsModelList){
                            if(itemsModel.getName().contains(searchStr)|| itemsModel.getDesc().contains(searchStr)){
                                resultsData.add(itemsModel);
                            }
                            filterResults.count = resultsData.size();
                            filterResults.values = resultsData;
                        }
                    }
                    return filterResults;
                }

                @Override
                protected void publishResults(CharSequence constraint, FilterResults results) {
                    itemsModelListFiltered = (List<ItemsModel>) results.values;
                    notifyDataSetChanged();
                }
            };
            return filter;
        }
    }
}